plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.mamadga.walletfinder"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.mamadga.walletfinder"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }
}

dependencies {
    implementation("org.bouncycastle:bcprov-jdk18on:1.78.1")
}
